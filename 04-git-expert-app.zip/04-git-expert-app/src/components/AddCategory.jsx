import { useState } from 'react';



export const AddCategory = ( {onNewCategory} ) => {                         //setCategories es un input que nos viene de GifExpertApp

    const [ inputValue, setInputValue ] = useState('One Punch');    //inputValue es el valor del estado y setInputValue es para actualizar el valor del estado
    //inputValue tendra de valor "One Punch" la primera vez que randericemos

    const onInputChange = ({target}) => {       //recibe el target, el objetivo del evento y lo pone en el input
        setInputValue( target.value );           //el target value por ejemplo es una letra, un espacio... cualquier tecla del teclado
    }

    const onSubmit = ( event ) => {     //se le llama cuando se le da enter, desde el form
        event.preventDefault();    //esto hace que la pagina no se recarge cuando le de a enter
        if( inputValue.trim().length <= 1) return;          //si no se escribe nada que se salga de la funcion y no escriba en blanco, trim quita los espacios en blanco
        
        //setCategories( categories => [ ...categories, inputValue ] ); //categorias en estado actual => [anteriores, lo que meto ]
        onNewCategory( inputValue.trim() );    //se pasa el valor del input a onNewCategory
        setInputValue('');
    }

    return (
         <form onSubmit={onSubmit}>     
            <input                           
            type="text"
            placeholder="Buscar Gifs"
            value = { inputValue }       //tendra el valor del inputValue
            onChange = { onInputChange }       //lo pulso algo en el teclado, se llama a la funcion
            />
        </form>
    )
}
