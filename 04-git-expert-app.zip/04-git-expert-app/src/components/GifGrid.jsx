//este será nuestro nuevo componente(GifGrid quiero decir)

import { GifItem } from "./GifItem";
import { useFetchGifs } from "../hooks/useFetchGifs";


export const GifGrid = ( {category } ) => {        //recibimos como property la category

    const { images, isLoading } = useFetchGifs( category );

    return (
        <>
            <h3>{ category }</h3>
            {
                isLoading && ( <h2>Cargando...</h2>)      //si es true isLoading hace lo de la derecha de &&, si es false no hace nada
            
            }
            

            <div className = "card-grid">          {/*  className es como class en html */}
                {
                    images.map( ( image ) => (
                        <GifItem 
                            key = { image.id }
                            // title = { image.title }
                            // url = {image.url}
                            { ...image }  //todas las propiedades de la imagen que tenga con esto es igual que las dos lineas de arriba comentadas, nos sirve por si hay 100 properties, para que sea mas facil
                        />     
                    ))
                }
                
            </div>
        </>
    )
}
