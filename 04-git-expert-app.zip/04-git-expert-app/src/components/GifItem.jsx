
export const GifItem = ({ title, url, id }) => {

    console.log({title, url});

    return (
        <div className = "card">
            <img src={ url } alt={ title } />     {/* por si la imagen no se muestra, que se muestre el titulo */}
            <p>{ title }</p>
        </div>
  )
}
