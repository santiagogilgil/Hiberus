export const getGifs = async( category ) => {         //esta funcion sirve para pillar de una API los datos que necesitamos para los gifs, usada en GigGrid
      
    const url = `https://api.giphy.com/v1/gifs/search?api_key=VR4MxLlnicO4JJ1wJ5RuLfizzfCIsi4i&q=${ category }&limit=10` //es la comilla que esta en la tecla del {, ya que asi nos ahorramos lo de sumar cadena
    const resp = await fetch( url );   //si uso el await, tengo que ser funcion async(asincrona)
    const { data } = await resp.json();       //para desestructurar la data, es decir, para poder manejar sus datos

    const gifs = data.map( img => ({
        id: img.id,
        title: img.title,
        url: img.images.downsized_medium.url
    }))
    console.log(gifs);

    return gifs;
}