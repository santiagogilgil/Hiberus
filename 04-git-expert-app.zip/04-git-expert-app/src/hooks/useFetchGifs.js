import { useEffect, useState } from 'react';
import { getGifs } from '../helpers/getGifs';

export const useFetchGifs = ( category ) => {
    
    const [images, setImages] = useState([]);         //images empieza como un array vacio
    const [isLoading, setIsLoading] = useState(true);   //isLoading true mientras no haya imagenes

    const getImages = async() => {
        const newImages = await getGifs( category );
        setImages(newImages);                      //vamos añadiendo a images las nuevas imagenes
        setIsLoading(false);
    }
    
    useEffect( () => {
        getImages();
    }, [])           //esto hace que solo se dispare la primera vez que se crea, y no mas veces
    
    return{
        images,
        isLoading
    }
}
