import { useState } from "react"
import { AddCategory, GifGrid } from "./components";

export const GifExpertApp = () => {

    const [categories, setCategories] = useState(['One Punch']);  //inputValue es el valor del estado y setInputValue es para actualizar el valor del estado
    //inputValue tendra de valor "One Punch" "Dragon Ball" la primera vez que randericemos

    const onAddCategory = ( newCategory ) => {       //voy a recibir el String y voy a ponerlo abajo

        if( categories.includes(newCategory) )  return;     //si la categoria ya existe no haga nada, sino, la añade a la lista

        setCategories( [ newCategory, ...categories] );    //setCategories para cuando queremos cambiar las categorías. ...categories copia las que hay de primeras, y luego añade 'Valorant'
        //Para poner 'Valorant' al inicio, tendriamos que poner ['Valorant', ...categories]
    }

    return (
        <>
            <h1>GifExpertApp</h1>

           
            <AddCategory 
                onNewCategory = { onAddCategory }   //onNewCategory que viene de la clase AddCategory se le pasa el valor a onAddCategory para que introduzca en la lista
            />         

            {
                categories.map( ( category )=> (
                    <GifGrid key={ category } category={ category }/>        //mando la cateogria como llave y en GifGrid como property
                ))
            }
                
        </>
    )
}
